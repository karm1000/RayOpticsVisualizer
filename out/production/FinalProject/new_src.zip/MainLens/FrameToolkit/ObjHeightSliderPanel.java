package MainLens.FrameToolkit;


import javax.swing.*;
import java.awt.*;

public class ObjHeightSliderPanel extends JPanel {
    public static final Dimension size = new Dimension(ObjDistanceSliderPanel.size.height,
            CenterPanel.size.height-ObjDistanceSliderPanel.size.height);
    public ObjHeightSliderPanel(){

    }
}
