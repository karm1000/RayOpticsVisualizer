package MainLens.FrameToolkit;

import javax.swing.*;
import java.awt.*;

public class ObjDistanceSliderPanel extends JPanel {
    static int height = 100;
    public static final Dimension size = new Dimension(CenterPanel.size.width-height,height);
    public ObjDistanceSliderPanel(){

    }
}
