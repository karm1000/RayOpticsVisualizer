package MainLens.FrameToolkit;

import javax.swing.*;
import java.awt.*;

public class FocalLengthFloatingPanel extends JPanel {
    public static final Dimension size = new Dimension(500,500);

    public FocalLengthFloatingPanel(){
        this.setSize(size);
    }
}
